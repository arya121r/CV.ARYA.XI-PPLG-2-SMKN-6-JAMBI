<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM arya");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV ARYA RAMADHAN</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"> <img src="tonikross.jpg" alt="ini gambar saya">
    </div>
    <?php
    foreach ($cari as $cari2):
    ?>
    <h1><?= $cari2 ['nama'];?></h1>
    <h3><?php echo $cari2['hobi'];?></h3>
    <?php
    endforeach;
    ?>
    </div>
    <div class="main">
    <div class="left">
        <h2>Informasi Identitas</h2>
        <p><strong>NAMA :</strong>ARYA RAMADHAN</p>
        <p><strong>ALAMAT : </strong> <?php echo $cari2['alamat'];?></p>
        <p><strong>NO.TELEPON : </strong><?php echo $cari2 ['no_hp'];?></p>
        <p><strong>SKILL : </strong> <?php echo $cari2['skill'];?></p>
        <h2>Pendidikan</h2>
        <p><strong>Sekolah Dasar : </strong> SD 161</p>
        <p><strong>Sekolah Lanjut Tingkat Pertama : </strong> MTSN 4</p>
        <p><strong>Sekolah Menengah Kejuruan : </strong> SMK 6</p>
    </div>
    <div class="right">
        <h2>Pekerjaan</h2>
        <p><strong><?php echo $cari2['pekerjaan'];?> </strong></p>
        <h2>Hobi</h2>
        <p><strong><?php echo $cari2['hobi'];?> </strong></p>
       
       
    </div>
    </div>
    </div>
</body>
</html>