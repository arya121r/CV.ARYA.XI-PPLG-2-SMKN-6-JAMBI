<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
$database= mysqli_connect('localhost','root','','aryakw');//menampilkan Nama database
$hapus = $_GET ["no"]; //fungsi hapus
$data= mysqli_query ($database,"SELECT*FROM arya WHERE no=$hapus");

if(isset ($_POST["tombol"])){
    $no = $_POST ["no"];
    $nama = $_POST ["nama"];
    $kelas = $_POST ["kelas"];
    $umur = $_POST ["umur"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $hobi = $_POST ["hobi"];
    $alamat = $_POST ["alamat"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $edit = "UPDATE arya SET
    nama = '$nama',
    kelas = '$kelas',
    umur = '$umur',
    no_hp= '$no_hp',
    tanggal_lahir = '$tanggal_lahir',
    pengalaman = '$pengalaman',
     hobi = '$hobi',
     alamat = '$alamat',
     skill = '$skill',
      pendidikan = '$pendidikan'
    WHERE no=$hapus";

    mysqli_query($database,$edit);
    
    //cek apabila data sudah tersimpan
    if (mysqli_affected_rows($database)>0){
        echo "<script>
        alert ('Data Berhasil Diubah');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Diubah');
        document.location.href='index.php';
        </script>";
    }
}

?>
<!DOCTYPE html>
<head>
    <title>Edit Data</title>
</head>
<body>

<?php
    while($cari= mysqli_fetch_assoc ($data)):
    ?>
    <h2>Edit Data</h2>
    <form method="POST">
    <input type="hidden" name="no" value="<?= $cari ['no'];?>">
<ul>
<li><label >Nama</label></li>
<li><input type="text" name="nama" value="<?= $cari ['nama'];?>"></li>
<li><label >Jenis Kelamin</label></li>
<li>

    <select name="jenis_kelamin" required>
        <option>laki-laki</option>
        <option>perempuan</option>
</select>
</li>
    <?php
    if($cari["jenis_kelamin"]=="laki-laki")echo"<option value='laki-laki'selected>laki-laki</option";
    else echo "<optionvalue=='laki-laki' selected>laki-laki</option>";
    if($cari["jenis_kelamin"]=="perempuan")echo"<option value='perempuan'selected>perempuan</option";
    else echo "<optionvalue=='perempuan' selected>perempuan</option>";
    ?>
</li>
    <li><label >Kelas</label></li>
    <li><input type="text" name="kelas" value="<?= $cari ['kelas'];?>"></li>
    <li><label >Umur</label></li>
    <li><input type="text" name="umur" value="<?= $cari ["umur"];?>"></li>
    <li><label >No HP</label></li>
    <li><input type="text" name="no_hp" value="<?php echo $cari ['no_hp'];?>"></li>
    <li><label >Tanggal Lahir</label></li>
    <li><input type="text" name="tanggal_lahir" value="<?php echo $cari ['tanggal_lahir'];?>"></li>
    <li><label >Pengalaman</label></li>
    <li><input type="text" name="pengalaman" value="<?php echo $cari ['pengalaman'];?>"></li>
    <li><label >Hobi</label></li>
    <li><textarea name="hobi" id=""></textarea>
    <li><label >Alamat</label></li>
    <li><input type="text" name="alamat" value="<?php echo $cari ['alamat'];?>"></li>
    <li><label >Skill</label></li>
    <li><input type="text" name="skill" value="<?php echo $cari ['skill'];?>"></li>
    <li><label >Pendidikan</label></li>
    <li><textarea name="pendidikan"<? echo $cari ["pendidikan"]?>></textarea>
    <li><label >Pekerjaan</label></li>
    <li><textarea name="pekerjaan" id=""><?php echo $cari ["pekerjaan"]?></textarea></li>
    <li><button type="submit" name="tombol">Perbaharuin data</button></li>
</ul>
<?php
    endwhile;
    ?>
    </form>
</body>
</html>