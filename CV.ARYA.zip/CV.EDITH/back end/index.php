<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM arya");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM sri WHERE
    nama like '%$Pencarian%' or
     jenis_kelamin like '%$Pencarian%' or
   kelas like '%$Pencarian%'or
    umur like '%$Pencarian%' or
     no_hp like '%$Pencarian%' or
      tanggal_lahir like '%$Pencarian%' or
       penggalaman like '%$Pencarian%'or
       hobi like '%$Pencarian%' or
       alamat like '%$Pencarian%'or
        skill like '%$Pencarian%'or
        pendidikan like '%$Pencarian%'or
        pekerjaan like '%$Pencarian%'";
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM arya');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="Logo Sekolah">
    </div>
    <div id="header-title">
<a href="index.php">ARYA</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="login.php">Keluar</a></li>
        </ul>
    </div>
    <div class="konten">
<h1>RAMADHAN</h1> 
 
<a href="tambah.php">Tambah</a>
<form action="" method="post">
    <input type="text" name="pencarian">
    <button type="submit" name="tombol">Cari</button>
</form>
<div class="tabel">
<table border="1" cellspadding="20" callspacing= "10">
    <tr class="tabel-header">
        <th>No</th>
        <th>Nama</th>
        <th>Jenis_Kelamin</th>
        <th>Kelas</th>
        <th>Umur</th>
        <th>No_hp</th>
        <th>Tanggal_lahir</th>
        <th>penggalaman</th>
        <th>Hobi</th>
        <th>Alamat</th>
        <th>Skill</th>
        <th>Pendidikan</th>
        <th>Pekerjaan</th>
    </tr>
    <?php
    $nomor= 1; 
    ?>
    <?php
    foreach ($cari as $cari2):
    ?>
     <tr>
        <td class="tabel-header1"><?= $nomor;?></td>
        <td class="tabel-header2"><?= $cari2 ['nama'];?></td>
        <td class="tabel-header3"><?= $cari2 ['jenis_kelamin'];?></td>
        <td class="tabel-header4"><?= $cari2 ['kelas'];?></td>
        <td class="tabel-header5"><?php echo $cari2 ['umur'];?></td>
        <td class="tabel-header6"><?php echo $cari2 ['no_hp'];?></td>
        <td class="tabel-header7"><?php echo $cari2['tanggal_lahir'];?></td>
        <td class="tabel-header8"><?php echo $cari2['pengalaman'];?></td>
        <td class="tabel-header9"><?php echo $cari2['hobi'];?></td>
        <td class="tabel-header10"><?php echo $cari2['alamat'];?></td>
        <td class="tabel-header11"><?php echo $cari2['skill'];?></td>
        <td class="tabel-header12"><?php echo $cari2['pendidikan'];?></td>
        <td class="tabel-header13"><?php echo $cari2['pekerjaan'];?></td>
        </select></td>
        <td><a href="edit.php?no=<?= $cari2 ["no"]?>">Edit</a> |
            <a href="hapus.php?no=<?= $cari2 ["no"]?>">Hapus</a>
            <a href="keluar.php?no=<?= $cari2 ["no"]?>">Keluar</a>
        </td>
    </tr>
    <?php
    $nomor++;
    ?>
    <?php
    endforeach;
    ?>
  </table>
    <?php
    $nomor= 1; 
    ?>
    <?php
    foreach ($cari as $cari2):
    ?>
     
    <?php
    $nomor++;
    ?>
    <?php
    endforeach;
    ?>
  </table>


  </div>
  </div>
</body>
</html>